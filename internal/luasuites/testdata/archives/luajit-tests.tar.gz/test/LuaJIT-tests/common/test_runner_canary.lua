return "canary is alive"
